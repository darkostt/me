-- HUNTER_MM_Leveling.lua (Fixed)
-- Apep Combat Routine — Hunter (Marksmanship) Leveling 18 -> 60
-- Clean, minimal, production-style. English only.

local addonName, _A = ...

-- ========================= GUI =========================
local GUI = {
  { type="header", text="Hunter MM Leveling (18-60)", size=16, align="LEFT" },
  { type="ruler" },
  { type="text", text="AoE uses Multi-Shot at 3+ targets (toggle AoE).", size=12 },
  { type="text", text="Cooldowns toggle gates Rapid Fire, Readiness, Call of the Wild.", size=12 },
  { type="ruler" },
  { type="spinner", key="hp_mend_pet",    text="Mend Pet below %",   default=70, min=10, max=100, step=5 },
  { type="spinner", key="hp_deterrence",  text="Deterrence below %", default=25, min=5,  max=100, step=5 },
  { type="spinner", key="hp_feign",       text="Feign Death below %",default=15, min=5,  max=100, step=5 },
}

-- ==================== Load / Unload ====================
local exeOnLoad = function()
  _A.Interface:ShowToggle("cooldowns",  true)
  _A.Interface:ShowToggle("interrupts", true)
  _A.Interface:ShowToggle("aoe",        true)
end

local exeOnUnload = function() end

-- ======================= Utils =========================
local function isOnGCD()
  local start, duration = GetSpellCooldown(61304)
  if not start or duration <= 0 then return false end
  return (start + duration - GetTime()) > 0
end

-- Safe UI getter (no hard dependency on Interface:Get)
local function getUI(key, default)
  local ok, iface = pcall(function() return _A and _A.Interface end)
  if ok and iface and type(iface) == "table" and iface.Get then
    local okv, v = pcall(function() return iface:Get(key) end)
    if okv and (type(v) == "number" or type(v) == "boolean") then return v end
  end
  -- Optional DSL fallback if provided by your build
  if _A and _A.DSL and _A.DSL.Get then
    local okd, v2 = pcall(function() return _A.DSL:Get("ui")(_, key) end)
    if okd and (type(v2) == "number" or type(v2) == "boolean") then return v2 end
  end
  return default
end

local function validEnemy(t)
  return t and t:enemy() and t:alive() and not t:immune("all")
end

local function enemyCount(radius)
  local n = 0
  for _, obj in pairs(_A.OM:Get("Enemy")) do
    if obj:alive() and obj:los() and obj:range() <= (radius or 10) then
      n = n + 1
      if n >= 3 then break end
    end
  end
  return n
end

local function CastIfReady(player, target, spell)
  if not validEnemy(target) then return false end
  if not player:SpellReady(spell) then return false end
  if not player:SpellUsable(spell) then return false end
  if not target:SpellRange(spell) then return false end
  target:Cast(spell)
  return true
end

local function SelfCastIfReady(player, spell)
  if not player:SpellReady(spell) then return false end
  if not player:SpellUsable(spell) then return false end
  player:Cast(spell)
  return true
end

-- ==================== Pet Management ===================
local function EnsurePetActive(player)
  local pet = Object("pet")
  if pet and pet:alive() then return false end
  if player:SpellReady("Revive Pet") then
    return SelfCastIfReady(player, "Revive Pet")
  end
  if player:SpellReady("Call Pet 1") then
    return SelfCastIfReady(player, "Call Pet 1")
  end
  return false
end

local function HealPetIfNeeded(player)
  local pet = Object("pet")
  if not pet or not pet:alive() then return false end
  local th = getUI("hp_mend_pet", 70)
  if pet:Health() <= th then
    return SelfCastIfReady(player, "Mend Pet")
  end
  return false
end

-- ======================= Aspects =======================
local function KeepAspect(player)
  if player:combat() then
    if player:SpellReady("Aspect of the Hawk") and not player:Buff("Aspect of the Hawk") then
      return SelfCastIfReady(player, "Aspect of the Hawk")
    end
  else
    if player:SpellReady("Aspect of the Cheetah") and not player:Buff("Aspect of the Cheetah") then
      return SelfCastIfReady(player, "Aspect of the Cheetah")
    end
  end
  return false
end

-- ===================== Defensives ======================
local function CastDeterrence(player)
  local th = getUI("hp_deterrence", 25)
  if player:Health() <= th then
    return SelfCastIfReady(player, "Deterrence")
  end
  return false
end

local function CastFeignDeath(player)
  local th = getUI("hp_feign", 15)
  if player:Health() <= th then
    return SelfCastIfReady(player, "Feign Death")
  end
  return false
end

local function MobilityEscape(player, target)
  if player:SpellReady("Disengage") and target and target:range() <= 8 and player:Health() <= 50 then
    return SelfCastIfReady(player, "Disengage")
  end
  return false
end

-- ===================== Interrupts/CC ===================
local function TryInterrupt(player, target)
  if not target or not target:isCastingAny() then return false end
  if player:SpellReady("Silencing Shot") and target:SpellRange("Silencing Shot") and target:caninterrupt() then
    target:Cast("Silencing Shot")
    return true
  end
  if player:SpellReady("Scatter Shot") and target:SpellRange("Scatter Shot") then
    target:Cast("Scatter Shot")
    return true
  end
  return false
end

-- ===================== Maintenance =====================
local function KeepHuntersMark(player, target)
  if not validEnemy(target) then return false end
  if target:Debuff("Hunter's Mark") then return false end
  return CastIfReady(player, target, "Hunter's Mark")
end

local function MaintainSerpentSting(player, target)
  if not validEnemy(target) then return false end
  if not player:SpellReady("Serpent Sting") then return false end
  if not target:Debuff("Serpent Sting") or target:debuffduration("Serpent Sting") < 3 then
    return CastIfReady(player, target, "Serpent Sting")
  end
  return false
end

-- ======================= Cooldowns =====================
local function UseBurst(player, target)
  if not _A.DSL:Get("toggle")(_, "cooldowns") then return false end
  local used = false
  if player:SpellReady("Rapid Fire") then
    used = SelfCastIfReady(player, "Rapid Fire") or used
  end
  if player:SpellReady("Readiness") and player:Buff("Rapid Fire") then
    used = SelfCastIfReady(player, "Readiness") or used
  end
  if player:SpellReady("Call of the Wild") then
    used = SelfCastIfReady(player, "Call of the Wild") or used
  end
  return used
end

-- ========================= AoE =========================
local function CastAoE(player, target)
  if not _A.DSL:Get("toggle")(_, "aoe") then return false end
  if enemyCount(10) < 3 then return false end
  if player:SpellReady("Multi-Shot") and player:SpellUsable("Multi-Shot") then
    if validEnemy(target) and target:SpellRange("Multi-Shot") then
      target:Cast("Multi-Shot")
      return true
    end
    for _, e in pairs(_A.OM:Get("Enemy")) do
      if e:alive() and e:los() and e:SpellRange("Multi-Shot") then
        e:Cast("Multi-Shot")
        return true
      end
    end
  end
  return false
end

-- ============== Single-Target (MM Priority) ============
local function CastKillShot(player, target)
  if not validEnemy(target) then return false end
  if target:Health() <= 20 then
    return CastIfReady(player, target, "Kill Shot")
  end
  return false
end

local function CastChimeraShot(player, target)
  if not validEnemy(target) then return false end
  return CastIfReady(player, target, "Chimera Shot")
end

local function CastAimedShotProc(player, target)
  if not validEnemy(target) then return false end
  if player:Buff("Fire!") then
    return CastIfReady(player, target, "Aimed Shot")
  end
  return false
end

local function FocusDumpArcaneShot(player, target)
  if not validEnemy(target) then return false end
  -- rely on SpellUsable to ensure enough focus
  if player:SpellUsable("Arcane Shot") then
    return CastIfReady(player, target, "Arcane Shot")
  end
  return false
end

local function BuilderSteadyShot(player, target)
  if not validEnemy(target) then return false end
  if player:SpellReady("Steady Shot") and player:SpellUsable("Steady Shot") and target:SpellRange("Steady Shot") then
    target:Cast("Steady Shot")
    return true
  end
  return false
end

-- ===================== In-Combat =======================
local inCombat = function()
  local player = Object("player")
  local target = Object("target")
  if not player then return end
  if player:State("stun || fear || sleep || disorient || incapacitate") then return end
  if IsMounted() or isOnGCD() or player:isCastingAny() then return end

  _A.RunMacroText("/startattack")

  -- Basics
  if EnsurePetActive(player) then return end
  if HealPetIfNeeded(player) then return end
  if KeepAspect(player) then return end

  -- Defensives
  if CastDeterrence(player) then return end
  if CastFeignDeath(player) then return end
  if MobilityEscape(player, target) then return end

  -- Maintenance
  if KeepHuntersMark(player, target) then return end
  if MaintainSerpentSting(player, target) then return end

  -- Interrupts
  if _A.DSL:Get("toggle")(_, "interrupts") and target and target:isCastingAny() then
    if TryInterrupt(player, target) then return end
  end

  -- CDs
  UseBurst(player, target)

  -- Execute / AoE
  if CastKillShot(player, target) then return end
  if CastAoE(player, target) then return end

  -- MM Core
  if CastAimedShotProc(player, target) then return end
  if CastChimeraShot(player, target) then return end
  if FocusDumpArcaneShot(player, target) then return end
  if BuilderSteadyShot(player, target) then return end
end

-- ==================== Out-of-Combat ====================
local outCombat = function()
  local player = Object("player")
  if not player then return end
  if IsMounted() or isOnGCD() or player:isCastingAny() then return end

  EnsurePetActive(player)
  HealPetIfNeeded(player)
  KeepAspect(player)
end

_A.CR:Add("HUNTER", {
  name = "[Hunter] MM Leveling 18-60",
  ic = inCombat,
  ooc = outCombat,
  use_lua_engine = true,
  gui = GUI,
  gui_st = { title = "Hunter MM Leveling", color = "A0C1F2", width = 380, height = 300 },
  wow_ver = "4.3.4",
  apep_ver = "1.1",
  load = exeOnLoad,
  unload = exeOnUnload,
})
